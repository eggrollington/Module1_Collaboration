extends Control

@export var main_battle_scene : PackedScene = preload("res://scenes/battle_field.tscn")

func _ready():
	# Grab focus so the player can use a controller/keyboard immediately
	#$MenuOptions/StartButton.grab_focus()
	pass
	

func _on_options_button_pressed():
	print("Options menu not implemented yet!")

func _on_quit_button_pressed():
	get_tree().quit()


func _on_start_game_pressed() -> void:
	var tween = create_tween()
	tween.tween_property(self, "modulate", Color.BLACK, 0.5)
	await tween.finished
	get_tree().change_scene_to_packed(main_battle_scene)
